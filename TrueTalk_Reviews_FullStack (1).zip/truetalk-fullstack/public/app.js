const $ = id => document.getElementById(id);
let products = [];
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const stars = n => "★".repeat(n) + "☆".repeat(5-n);
async function api(url, options={}) {
  const res = await fetch(url, options);
  const data = await res.json().catch(()=>({}));
  if (!res.ok) throw new Error(data.error || "Something went wrong");
  return data;
}
function route(){
  const page = location.hash.slice(1) || "home";
  document.querySelectorAll(".page").forEach(p=>p.classList.toggle("active",p.id===page));
  document.querySelectorAll("nav a").forEach(a=>a.classList.toggle("active",a.getAttribute("href")==="#"+page));
  if(page==="reviews") loadFeed();
  window.scrollTo(0,0);
}
window.addEventListener("hashchange",route);
function productCard(p){
  return `<article class="productCard"><h3>${esc(p.name)}</h3><div class="meta">${esc(p.type)} · ₹${p.price.toLocaleString("en-IN")}</div><div class="numbers"><div><span class="meta">Raw rating</span><strong>${p.rawRating.toFixed(1)} ★</strong></div><div><span class="meta">True quality</span><strong>${p.adjustedRating.toFixed(1)} ★</strong></div></div><div class="meta">${p.reviewCount} reviews · ${p.verifiedPercent}% verified</div><div class="track"><div class="fill" style="width:${p.adjustedRating/5*100}%"></div></div><p class="meta">Battery: ${p.claimedBattery}h claimed / ${p.measuredBattery}h sample measured</p></article>`;
}
async function loadProducts(){
  products = await api("/api/products");
  $("products").innerHTML = products.map(productCard).join("");
  $("productId").innerHTML = products.map(p=>`<option value="${p.id}">${esc(p.name)}</option>`).join("");
  const p=products[0]; $("heroRaw").textContent=p.rawRating+" ★";$("heroAdjusted").textContent=p.adjustedRating+" ★";
  $("heroCaption").textContent=`${p.name}: ${p.reviewCount} sample reviews; ${p.verifiedPercent}% marked as verified purchases.`;
  $("heroBar").style.width=(p.adjustedRating/5*100)+"%";
}
async function loadFeed(){
  const q=encodeURIComponent($("search").value||""), type=encodeURIComponent($("type").value||""), sort=encodeURIComponent($("sort").value);
  const rows=await api(`/api/reviews?q=${q}&type=${type}&sort=${sort}`);
  $("reviewFeed").innerHTML=rows.map(r=>{
    const a=r.analysis, tag=a.fakeProbability>=70?"red":a.fakeProbability>=40?"amber":"green";
    return `<article class="review"><div class="reviewHead"><div><strong>${esc(r.productName)}</strong> · ${esc(r.reviewer)}<div class="stars">${stars(r.rating)}</div></div><div><span class="tag ${tag}">${esc(a.tier)}</span> <span class="tag">${a.fakeProbability}% fake probability</span></div></div><p>${esc(r.text)}</p><div class="meta">${r.verified?'<span class="tag green">Verified purchase</span>':'<span class="tag amber">Unverified</span>'} · ${esc(r.sentiment||a.sentiment)} sentiment · ${a.wordCount} words</div><div class="reviewActions"><button class="smallBtn" data-helpful="${r.id}">Helpful · ${r.helpfulVotes}</button><span class="meta">Authenticity ${a.authenticityScore}/100</span><button class="smallBtn" data-details="${r.id}">Why this score?</button><span class="meta" data-reasons="${r.id}" hidden>${a.reasons.map(esc).join(" · ")}</span></div></article>`;
  }).join("") || "<p>No reviews match these filters.</p>";
}
$("reviewFeed").addEventListener("click",async e=>{
  const helpful=e.target.dataset.helpful, details=e.target.dataset.details;
  try{
    if(helpful){await api(`/api/reviews/${helpful}/helpful`,{method:"POST"});loadFeed();}
    if(details){const el=document.querySelector(`[data-reasons="${details}"]`);el.hidden=!el.hidden;}
  }catch(err){alert(err.message);}
});
["search","type","sort"].forEach(id=>$(id).addEventListener(id==="search"?"input":"change",loadFeed));
function renderAnalysis(a,target){
  const color=a.fakeProbability>=70?"#b52f24":a.fakeProbability>=40?"#946000":"#16875a";
  target.innerHTML=`<div class="panel result"><div class="score" style="color:${color}">${a.fakeProbability}%</div><strong>${esc(a.tier)}</strong><p>Authenticity score: ${a.authenticityScore}/100 · Sentiment: ${esc(a.sentiment)} · Lexical diversity: ${a.lexicalDiversity}</p>${a.reasons.map(x=>`<div class="reason">${esc(x)}</div>`).join("")}<p class="meta">${esc(a.disclaimer)}</p></div>`;
}
$("runCheck").addEventListener("click",async()=>{
  try{const a=await api("/api/analyze",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({text:$("checkText").value,rating:$("checkRating").value,verified:$("checkVerified").checked})});renderAnalysis(a,$("checkResult"));}
  catch(e){$("checkResult").textContent=e.message;}
});
$("previewAnalysis").addEventListener("click",async()=>{
  try{const a=await api("/api/analyze",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({text:$("reviewText").value,rating:$("rating").value,verified:$("verified").value==="true"})});renderAnalysis(a,$("submitAnalysis"));}
  catch(e){$("submitAnalysis").textContent=e.message;}
});
$("reviewForm").addEventListener("submit",async e=>{
  e.preventDefault();$("formMessage").textContent="Publishing…";
  try{
    const fd=new FormData(e.target);
    const result=await api("/api/reviews",{method:"POST",body:fd});
    $("formMessage").textContent=`Review published. Authenticity risk: ${result.analysis.fakeProbability}%.`;
    e.target.reset();$("submitAnalysis").innerHTML="";await loadProducts();location.hash="reviews";
  }catch(err){$("formMessage").textContent=err.message;}
});
$("media").addEventListener("change",()=>{
  const f=$("media").files[0];$("livePreview").textContent=f?`${f.name} selected (${(f.size/1024/1024).toFixed(2)} MB)`:"";
});
$("simulateImport").addEventListener("click",async()=>{
  try{const data=await api("/api/import-simulator",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({url:$("sourceUrl").value})});$("importResult").innerHTML=`<div class="panel result"><strong>${esc(data.message)}</strong><p>${data.imported} sample reviews audited · ${data.flagged} flagged</p><p class="meta">${esc(data.note)}</p></div>`;}
  catch(e){$("importResult").textContent=e.message;}
});
loadProducts().then(route).catch(e=>{console.error(e);$("heroCaption").textContent="Could not connect to the API. Start the server and refresh.";});
