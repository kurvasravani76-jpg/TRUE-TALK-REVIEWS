# TrueTalk Reviews – FakeFilter (Full-Stack Version)

A responsive product-review platform with a Node.js/Express backend, persistent JSON database, review authenticity analysis, adjusted product ratings and a review submission workflow.

## Features

- Product catalogue and review feed with search, product-type filters and sorting.
- Star ratings, verified-purchase labels, helpful votes and sentiment badges.
- Backend review analyzer: promotional hype, repeated phrases, punctuation/capitalization patterns, lexical diversity, product-use detail, incentive wording and rating/sentiment mismatch.
- Individual fake-review probability, authenticity score, risk tier and transparent reasons.
- Adjusted **True Quality Rating**: averages reviews with a heuristic fake probability below 60%; raw average is also shown.
- Review submission with pre-submit analysis and optional image/video upload (10 MB maximum).
- Reviewer credibility endpoint.
- URL import simulator (does not scrape external websites).
- Persistent data in `data/db.json`.

## Requirements

- Node.js 18 or newer
- npm

## Run locally

1. Extract the ZIP file.
2. Open a terminal in the extracted `truetalk-fullstack` folder.
3. Install dependencies:

   ```bash
   npm install
   ```

4. Start the server:

   ```bash
   npm start
   ```

5. Open **http://localhost:3000** in your browser.

For development with automatic server restart, run `npm run dev`.

## Project structure

```text
truetalk-fullstack/
├── data/
│   ├── db.json             # Persistent products and review records
│   └── products.json       # Seed product catalogue
├── public/
│   ├── index.html          # Frontend pages
│   ├── styles.css          # Responsive styling
│   └── app.js              # Frontend/API integration
├── src/
│   └── analyzer.js         # Review authenticity heuristics
├── uploads/                # Uploaded review media (created/used by server)
├── server.js               # Express API and static web server
├── package.json
└── README.md
```

## API reference

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/health` | API health check |
| GET | `/api/products` | Product catalogue with raw/adjusted ratings |
| GET | `/api/products/:id` | Product details and its reviews |
| GET | `/api/reviews` | Review feed; optional `q`, `type`, `productId`, `sort` |
| POST | `/api/analyze` | Analyze review text without saving |
| POST | `/api/reviews` | Submit review (`multipart/form-data`; optional `media`) |
| POST | `/api/reviews/:id/helpful` | Add one helpful vote |
| POST | `/api/import-simulator` | Simulate a public-URL review audit |
| GET | `/api/credibility/:reviewer` | Reviewer history/credibility estimate |

### Example: analyze a review

```bash
curl -X POST http://localhost:3000/api/analyze \
  -H "Content-Type: application/json" \
  -d '{"text":"Battery lasted about six hours. Bass is clear but calls have some background noise.","rating":4,"verified":true}'
```

## Scoring notes

The analyzer is a transparent, rule-based demonstration and is not a trained machine-learning classifier. Its risk score uses language patterns and metadata signals. A positive or enthusiastic review is not automatically fake. Scores should not be used as proof or as the sole basis for moderation decisions.

The adjusted rating excludes reviews whose heuristic fake probability is **60 or higher**. This threshold is configurable in `server.js` (`productSummary`).

## Data and reset

The initial database contains six sample audio products and 40 simulated reviews (25 intended as authentic examples and 15 synthetic/promotional examples). The examples are for demonstration only and are not real customer testimonials or product measurements.

To reset all demo records, restore `data/db.json` from the original ZIP or edit it while the server is stopped. Uploaded media is stored in `uploads/`.

## Limitations / next steps

- JSON-file persistence is suitable for a local hackathon demo, not concurrent production traffic. Replace it with SQLite or PostgreSQL before deployment.
- Purchase verification is a user-declared demo field, not a retailer-confirmed verification.
- The URL importer is deliberately a simulator and does not fetch third-party pages.
- Reviewer credibility is a simple history-based estimate and should not be treated as identity verification.
- Add authentication, authorization, rate limiting, moderation and secure cloud storage before public deployment.

## Tech stack

- Frontend: HTML, CSS, JavaScript, Chart.js CDN reference included for future chart extensions
- Backend: Node.js, Express, Multer
- Storage: persistent JSON file
