const POSITIVE = ["good","great","clear","comfortable","useful","reliable","balanced","excellent","smooth","strong","worth","easy","impressive","durable","love"];
const NEGATIVE = ["bad","poor","weak","issue","problem","broken","uncomfortable","disappoint","noise","delay","worse","overpriced","drain","struggle","annoying"];
const HYPE = ["best ever","amazing","perfect","must buy","must-buy","life-changing","game changer","unbelievable","incredible","awesome","buy now","100% genuine"];
const GENERIC = ["highly recommend","value for money","go for it","don't think twice","must have"];

function analyzeReview(text, rating = 3, verified = false) {
  const raw = String(text || "").trim();
  const lower = raw.toLowerCase();
  const words = lower.match(/[a-z0-9']+/g) || [];
  const unique = new Set(words);
  const ttr = words.length ? unique.size / words.length : 0;
  const reasons = [];
  let risk = 12;
  const hypeCount = HYPE.filter(x => lower.includes(x)).length;
  const genericCount = GENERIC.filter(x => lower.includes(x)).length;
  const repeated = /\b(\w{3,})\b(?:[\s,!.]+\1){2,}/i.test(raw);
  const exclamations = (raw.match(/!/g) || []).length;
  const caps = (raw.match(/\b[A-Z]{3,}\b/g) || []).length;
  const technical = /\b(battery|hours|bass|treble|bluetooth|anc|latency|mic|microphone|fit|range|charging|case|volume|codec|price|₹|km)\b/i.test(raw);
  const pos = POSITIVE.filter(x => lower.includes(x)).length;
  const neg = NEGATIVE.filter(x => lower.includes(x)).length;
  const sentiment = pos > neg ? "Positive" : neg > pos ? "Negative" : "Mixed";
  if (words.length < 25) { risk += 18; reasons.push("Very short review with limited usage detail"); }
  if (hypeCount) { risk += Math.min(24, hypeCount * 8); reasons.push("Excessive promotional superlatives"); }
  if (genericCount >= 2) { risk += 10; reasons.push("Generic promotional phrasing"); }
  if (repeated) { risk += 18; reasons.push("Repeated words or phrases"); }
  if (exclamations >= 4) { risk += 10; reasons.push("Unusually high punctuation repetition"); }
  if (caps >= 3) { risk += 7; reasons.push("Several words written in all caps"); }
  if (ttr < 0.48 && words.length >= 25) { risk += 10; reasons.push("Low lexical diversity"); }
  if (!technical) { risk += 8; reasons.push("No specific product-use details detected"); }
  if (!/\b(but|however|although|issue|problem|only|wish|except|drawback|sometimes)\b/i.test(raw)) { risk += 5; reasons.push("No trade-off or limitation mentioned"); }
  if (/\b(free|gifted|sponsored|in exchange for|promo code)\b/i.test(lower)) { risk += 12; reasons.push("Possible incentive disclosure detected"); }
  if (!verified) { risk += 8; reasons.push("Purchase is not verified"); }
  risk = Math.max(1, Math.min(98, risk));
  const mismatch = (Number(rating) >= 4 && neg >= pos + 2) || (Number(rating) <= 2 && pos >= neg + 2);
  if (mismatch) { risk = Math.min(98, risk + 12); reasons.push("Star rating and review sentiment may not match"); }
  const tier = risk >= 70 ? "Likely Fake/Bot" : risk >= 40 ? "Suspicious" : "Likely Genuine";
  return {
    fakeProbability: risk, authenticityScore: 100 - risk, tier, sentiment,
    lexicalDiversity: +ttr.toFixed(2), wordCount: words.length,
    ratingMismatch: mismatch, reasons: reasons.length ? reasons : ["No strong suspicious patterns detected"],
    disclaimer: "Heuristic estimate only. This score is not proof that a review is fake."
  };
}
module.exports = { analyzeReview };
