const express = require("express");
const path = require("path");
const fs = require("fs");
const multer = require("multer");
const { analyzeReview } = require("./src/analyzer");

const app = express();
const PORT = process.env.PORT || 3000;
const DATA = path.join(__dirname, "data", "db.json");
const uploadDir = path.join(__dirname, "uploads");
fs.mkdirSync(uploadDir, { recursive: true });

app.use(express.json({ limit: "2mb" }));
app.use("/uploads", express.static(uploadDir));
app.use(express.static(path.join(__dirname, "public")));

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, uploadDir),
  filename: (_req, file, cb) => {
    const safe = file.originalname.replace(/[^a-zA-Z0-9._-]/g, "_").slice(-80);
    cb(null, `${Date.now()}-${safe}`);
  }
});
const upload = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    if (/^(image\/(jpeg|png|webp)|video\/mp4|video\/webm)$/.test(file.mimetype)) cb(null, true);
    else cb(new Error("Only JPG, PNG, WEBP, MP4 and WEBM files are allowed."));
  }
});

function readDB() {
  return JSON.parse(fs.readFileSync(DATA, "utf8"));
}
function writeDB(db) {
  fs.writeFileSync(DATA, JSON.stringify(db, null, 2));
}
function publicReview(r) {
  return { ...r, analysis: r.analysis || analyzeReview(r.text, r.rating, r.verified) };
}
function productSummary(db, product) {
  const reviews = db.reviews.filter(r => r.productId === product.id);
  const raw = reviews.length ? reviews.reduce((s, r) => s + r.rating, 0) / reviews.length : 0;
  const trusted = reviews.filter(r => r.analysis.fakeProbability < 60);
  const adjusted = trusted.length ? trusted.reduce((s, r) => s + r.rating, 0) / trusted.length : raw;
  const verified = reviews.filter(r => r.verified).length;
  return { ...product, reviewCount: reviews.length, rawRating: +raw.toFixed(1),
    adjustedRating: +adjusted.toFixed(1), verifiedPercent: reviews.length ? Math.round(verified / reviews.length * 100) : 0,
    distribution: [5,4,3,2,1].map(star => ({ star, count: reviews.filter(r => r.rating === star).length })) };
}

app.get("/api/health", (_req, res) => res.json({ status: "ok", service: "TrueTalk Reviews API" }));
app.get("/api/products", (_req, res) => {
  const db = readDB();
  res.json(db.products.map(p => productSummary(db, p)));
});
app.get("/api/products/:id", (req, res) => {
  const db = readDB();
  const p = db.products.find(x => x.id === req.params.id);
  if (!p) return res.status(404).json({ error: "Product not found" });
  res.json({ ...productSummary(db, p), reviews: db.reviews.filter(r => r.productId === p.id).map(publicReview) });
});
app.get("/api/reviews", (req, res) => {
  const db = readDB();
  let rows = db.reviews.map(publicReview);
  if (req.query.productId) rows = rows.filter(r => r.productId === req.query.productId);
  if (req.query.type) rows = rows.filter(r => r.productType === req.query.type);
  if (req.query.q) {
    const q = String(req.query.q).toLowerCase();
    rows = rows.filter(r => `${r.productName} ${r.text} ${r.reviewer}`.toLowerCase().includes(q));
  }
  if (req.query.sort === "helpful") rows.sort((a,b) => b.helpfulVotes - a.helpfulVotes);
  else if (req.query.sort === "risk") rows.sort((a,b) => b.analysis.fakeProbability - a.analysis.fakeProbability);
  else rows.sort((a,b) => new Date(b.createdAt) - new Date(a.createdAt));
  res.json(rows);
});
app.post("/api/analyze", (req, res) => {
  const { text, rating, verified } = req.body || {};
  if (typeof text !== "string" || text.trim().length < 20) return res.status(400).json({ error: "Enter at least 20 characters." });
  res.json(analyzeReview(text, Number(rating || 3), Boolean(verified)));
});
app.post("/api/reviews", upload.single("media"), (req, res) => {
  const db = readDB();
  const { productId, reviewer, rating, text, verified } = req.body;
  const product = db.products.find(p => p.id === productId);
  if (!product) return res.status(400).json({ error: "Choose a valid product." });
  if (!reviewer || String(reviewer).trim().length < 2) return res.status(400).json({ error: "Enter a reviewer name." });
  if (!text || String(text).trim().length < 40) return res.status(400).json({ error: "Review must contain at least 40 characters." });
  const stars = Number(rating);
  if (!Number.isInteger(stars) || stars < 1 || stars > 5) return res.status(400).json({ error: "Rating must be between 1 and 5." });
  const analysis = analyzeReview(text, stars, verified === "true");
  const review = {
    id: `r-${Date.now()}`, productId, productName: product.name, productType: product.type,
    reviewer: String(reviewer).trim(), rating: stars, text: String(text).trim(),
    verified: verified === "true", helpfulVotes: 0, sentiment: analysis.sentiment,
    analysis, mediaUrl: req.file ? `/uploads/${req.file.filename}` : null,
    createdAt: new Date().toISOString()
  };
  db.reviews.unshift(review);
  writeDB(db);
  res.status(201).json(publicReview(review));
});
app.post("/api/reviews/:id/helpful", (req, res) => {
  const db = readDB();
  const review = db.reviews.find(r => r.id === req.params.id);
  if (!review) return res.status(404).json({ error: "Review not found" });
  review.helpfulVotes += 1;
  writeDB(db);
  res.json({ helpfulVotes: review.helpfulVotes });
});
app.post("/api/import-simulator", (req, res) => {
  const { url } = req.body || {};
  if (!url || !/^https?:\/\//i.test(url)) return res.status(400).json({ error: "Enter a valid public product URL." });
  res.json({ message: "Demo import completed. This simulator does not scrape external websites.",
    sourceUrl: url, imported: 5, flagged: 2, note: "Sample audit data only." });
});
app.get("/api/credibility/:reviewer", (req, res) => {
  const db = readDB();
  const name = decodeURIComponent(req.params.reviewer).toLowerCase();
  const rows = db.reviews.filter(r => r.reviewer.toLowerCase() === name);
  const suspicious = rows.filter(r => r.analysis.fakeProbability >= 60).length;
  const score = rows.length ? Math.max(0, Math.round(100 - suspicious / rows.length * 65 - Math.max(0, rows.length - 5) * 3)) : 50;
  res.json({ reviewer: req.params.reviewer, reviewCount: rows.length, suspiciousCount: suspicious, credibility: score });
});
app.use((err, _req, res, _next) => res.status(400).json({ error: err.message || "Request failed" }));
app.get("*", (_req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));
app.listen(PORT, () => console.log(`TrueTalk running at http://localhost:${PORT}`));
